from flask import Flask, request, jsonify, make_response
from functools import wraps
import psycopg2
import os
import avro
import pandas as pd
import json


app = Flask(__name__)

#Make a function to authenticate the user:
def authetication(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        auth = request.authorization
        if auth and auth.username == 'globant' and auth.password == 'globant123':
            return f(*args, **kwargs)
        return make_response('Could not verify your login!', 401, {'WWW-Authenticate': 'Basic realm="Login Required"'})
    return decorated

#Set the database connection:
def db_connection():
    #Set the databse connection by using the psycopg2 library with the following parameters:
    conn = psycopg2.connect(dbname="globant", user="postgres", password="Adam123456", host="localhost", port="5432")
    #Print the connection status to check if it is successful:
    print("Database Connected Successfully")
    return conn

#Test get call to check if the server is running:
@app.route("/", methods=['GET'])
@authetication
def home():
    return "<h1>Server is working</h1>"

#Create the tables in the globant database:
def table_creation():
    conn = db_connection()
    cur = conn.cursor()
    #Create the departments table:
    cur.execute("CREATE TABLE IF NOT EXISTS departments (id SERIAL PRIMARY KEY, department VARCHAR(255) NOT NULL);")
    #Create the jobs table:
    cur.execute("CREATE TABLE IF NOT EXISTS jobs (id SERIAL PRIMARY KEY, job VARCHAR(255) NOT NULL);")
    #Create the hired_employees table:
    cur.execute("CREATE TABLE IF NOT EXISTS hired_employees (id SERIAL PRIMARY KEY, name VARCHAR(255) NOT NULL, datetime VARCHAR(255) NOT NULL, department_id INTEGER REFERENCES departments(id), job_id INTEGER REFERENCES jobs(id));")
    #Commit the changes:
    conn.commit()
    #Close the connection:
    conn.close()
    return "Table Created Successfully"


#Get call to get all the departments from the globant database:
@app.route("/departments", methods=['GET'])
@authetication
def get_departments():
    conn = db_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM departments;")
    rows = cur.fetchall()
    cur.close()
    conn.close()
    return jsonify(rows)

#Get call to get all the jobs from the globant database:
@app.route("/jobs", methods=['GET'])
@authetication
def get_jobs():
    conn = db_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM jobs;")
    rows = cur.fetchall()
    cur.close()
    conn.close()
    return jsonify(rows)

#Get call to get all the Employees from the globant database:
@app.route("/employees", methods=['GET'])
@authetication
def get_employees():
    conn = db_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM hired_employees;")
    rows = cur.fetchall()
    cur.close()
    conn.close()
    return jsonify(rows)

#POST CALLS:

#Post call to add a several department records to the globant database:
@app.route("/add/departments", methods=['POST'])
@authetication
def add_departments():
    conn = db_connection()
    cur = conn.cursor()
    departments = request.json

    # Check if all departments have all the information
    for department in departments:
        if not all(key in department for key in ['id', 'department']):
            return "Department data is incomplete"

    # Check if id already exists in the database
    for department in departments:
        cur.execute("SELECT COUNT(*) FROM departments WHERE id = %s;", (department['id'],))
        count = cur.fetchone()[0]
        if count > 0:
            return "Department with id {} already exists".format(department['id'])

    # Insert the departments into the database:
    sql = "INSERT INTO departments (id, department) VALUES (%s, %s);"
    values = [(department['id'], department['department']) for department in departments]
    cur.executemany(sql, values)
    conn.commit()
    return "Departments Added Successfully"


#Post call to add a several job records to the globant database:
@app.route("/add/jobs", methods=['POST'])
@authetication
def add_jobs():
    conn = db_connection()
    cur = conn.cursor()
    jobs = request.json

    # Check if all jobs have all the information
    for job in jobs:
        if not all(key in job for key in ['id', 'job']):
            return "Job data is incomplete"

    # Check if id already exists in the database
    for job in jobs:
        cur.execute("SELECT COUNT(*) FROM jobs WHERE id = %s;", (job['id'],))
        count = cur.fetchone()[0]
        if count > 0:
            return "Job with id {} already exists".format(job['id'])

    # Insert the jobs into the database:
    sql = "INSERT INTO jobs (id, job) VALUES (%s, %s);"
    values = [(job['id'], job['job']) for job in jobs]
    cur.executemany(sql, values)
    conn.commit()
    return "Jobs Added Successfully"



#Post call to add a several employees records to the globant database:
@app.route("/add/employees", methods=['POST'])
@authetication
def add_employees():
    conn = db_connection()
    cur = conn.cursor()
    employees = request.json

    # Check if all employees have all the information
    for employee in employees:
        if not all(key in employee for key in ['id', 'name', 'datetime', 'department_id', 'job_id']):
            return "Employee data is incomplete"

    # Check if id already exists in the database
    for employee in employees:
        cur.execute("SELECT COUNT(*) FROM hired_employees WHERE id = %s;", (employee['id'],))
        count = cur.fetchone()[0]
        if count > 0:
            return "Employee with id {} already exists".format(employee['id'])

    # Insert the employees into the database:
    sql = "INSERT INTO hired_employees (id, name, datetime, department_id, job_id) VALUES (%s, %s, %s, %s, %s);"
    values = [(employee['id'], employee['name'], employee['datetime'], employee['department_id'], employee['job_id']) for employee in employees]
    cur.executemany(sql, values)
    conn.commit()
    return "Employees Added Successfully"

###################################################################################################################################
#Features:

# Get the departments table and save it as a backup in a local folder as txt file:
@app.route("/departments/backup", methods=['GET'])
@authetication
def backup_departments(file_path="departments_backup.txt"):
    conn = db_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM departments;")
    rows = cur.fetchall()
    cur.close()
    conn.close()

    with open(file_path, "w") as f:
        for row in rows:
            f.write(str(row) + "\n")

def main():
    backup_departments()

# Get the jobs table and save it as a backup in a local folder as txt file:
@app.route("/jobs/backup", methods=['GET'])
@authetication
def backup_jobs(file_path="jobs_backup.txt"):
    conn = db_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM jobs;")
    rows = cur.fetchall()
    cur.close()
    conn.close()

    with open(file_path, "w") as f:
        for row in rows:
            f.write(str(row) + "\n")

def main():
    backup_jobs()

# Get the employees table and save it as a backup in a local folder as txt file:
@app.route("/employees/backup", methods=['GET'])
@authetication
def backup_employees(file_path="hired_employees.txt"):
    conn = db_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM hired_employees;")
    rows = cur.fetchall()
    cur.close()
    conn.close()

    with open(file_path, "w") as f:
        for row in rows:
            f.write(str(row) + "\n")

def main():
    backup_employees()

########################################################Restore the backups#############################################################################

#Restore the backup departments.txt to the globant database:
@app.route("/restore/departments", methods=['POST'])
@authetication
def get_backup_apartments(file_path):
    if not os.path.exists(file_path):
        raise FileNotFoundError("File does not exist")

    with open(file_path, "r") as f:
        backup_data = json.load(f)
    return backup_data

def restore_table(table_name, backup_data):
    conn = db_connection()
    cur = conn.cursor()

    cur.execute("DROP TABLE IF EXISTS {}".format(table_name))
    cur.execute("CREATE TABLE {} (id SERIAL PRIMARY KEY, department VARCHAR(255) NOT NULL)".format(table_name))

    for row in backup_data:
        cur.execute("INSERT INTO {} (id, department) VALUES ({},{})".format(table_name, row["id"], row["department"]))

    conn.commit()
    cur.close()
    conn.close()

def main():
    backup_data = get_backup_apartments("departments_backup.txt")

    restore_table("departments", backup_data)



#Restore the backup jobs.txt to the globant database:
@app.route("/restore/jobs", methods=['POST'])
@authetication
def get_backup_jobs(file_path):
    if not os.path.exists(file_path):
        raise FileNotFoundError("File does not exist")

    with open(file_path, "r") as f:
        backup_data = json.load(f)
    return backup_data

def restore_table(table_name, backup_data):
    conn = db_connection()
    cur = conn.cursor()

    cur.execute("DROP TABLE IF EXISTS {}".format(table_name))
    cur.execute("CREATE TABLE {} (id SERIAL PRIMARY KEY, job VARCHAR(255) NOT NULL)".format(table_name))

    for row in backup_data:
        cur.execute("INSERT INTO {} (id, job) VALUES ({},{})".format(table_name, row["id"], row["job"]))

    conn.commit()
    cur.close()
    conn.close()

def main():
    backup_data = get_backup_jobs("jobs_backup.txt")

    restore_table("jobs", backup_data)



#Restore the backup hired_employees.txt to the globant database:
@app.route("/restore/employees", methods=['POST'])
@authetication
def get_backup_employees(file_path):
    if not os.path.exists(file_path):
        raise FileNotFoundError("File does not exist")

    with open(file_path, "r") as f:
        backup_data = json.load(f)
    return backup_data

def restore_table(table_name, backup_data):
    conn = db_connection()
    cur = conn.cursor()

    cur.execute("DROP TABLE IF EXISTS {}".format(table_name))
    cur.execute("CREATE TABLE {} (id SERIAL PRIMARY KEY, name VARCHAR(255) NOT NULL, datetime VARCHAR(255) NOT NULL, department_id INTEGER REFERENCES departments(id), job_id INTEGER REFERENCES jobs(id))".format(table_name))

    for row in backup_data:
        cur.execute("INSERT INTO {} (id, name, datetime, department_id, job_id) VALUES ({},{},{},{},{})".format(table_name, row["id"], row["name"], row["datetime"], row["department_id"], row["job_id"]))

    conn.commit()
    cur.close()
    conn.close()

def main():
    backup_data = get_backup_employees("hired_employees.txt")

    restore_table("hired_employees", backup_data)


##################################################################################################################################QUERYS:

#Query number 1:
HIRE_DETAILS ="""WITH table_1 AS (
    SELECT
      d.department,
      h.department_id,
      h.job_id,
      h.id AS employee_id,
      h.name,
      h.datetime
    FROM departments d
    JOIN hired_employees h ON d.id = h.department_id
  ),
  table_2 AS (
    SELECT
      j.job,
      t1.department,
      t1.datetime,
      t1.name
    FROM jobs j
    JOIN table_1 t1 ON j.id = t1.job_id
  )

SELECT
  department,
  job,
  SUM(CASE WHEN Quarters = 'Q1' THEN Total ELSE 0 END) AS Q1,
  SUM(CASE WHEN Quarters = 'Q2' THEN Total ELSE 0 END) AS Q2,
  SUM(CASE WHEN Quarters = 'Q3' THEN Total ELSE 0 END) AS Q3,
  SUM(CASE WHEN Quarters = 'Q4' THEN Total ELSE 0 END) AS Q4
FROM (
  SELECT
    COUNT(name) as Total,
    job,
    department,
    CASE
    	WHEN datetime like '2021-01%' or datetime like '2021-02%' or datetime like '2021-03%' THEN 'Q1'
    	WHEN datetime like '2021-04%' or datetime like '2021-05%' or datetime like '2021-06%' THEN 'Q2'
    	WHEN datetime like '2021-07%' or datetime like '2021-08%' or datetime like '2021-09%' THEN 'Q3'
    	WHEN datetime like '2021-10%' or datetime like '2021-11%' or datetime like '2021-12%' THEN 'Q4'
    END as Quarters
  FROM table_2
  WHERE 
    datetime like '2021%' and name != 'N/A'
  GROUP BY
    job, department, Quarters
) AS table_3
GROUP BY job, department;
 """

#Query number 2:
HIRE_AMOUNT = """SELECT
  d.id,
  d.department,
  COUNT(h.name) AS num_hired
FROM
  departments d
JOIN
  hired_employees h ON d.id = h.department_id
JOIN
  jobs j ON h.job_id = j.id
WHERE
  h.datetime LIKE '2021%' AND h.name != 'N/A'
GROUP BY
  d.department, d.id
HAVING
  COUNT(h.name) > (
    SELECT AVG(num_hired)
    FROM (
      SELECT COUNT(h2.name) as num_hired
      FROM departments d2
      JOIN hired_employees h2 ON d2.id = h2.department_id
      JOIN jobs j2 ON h2.job_id = j2.id
      WHERE h2.datetime LIKE '2021%' AND h2.name != 'N/A'
      GROUP BY d2.department
    ) AS subquery
  )
ORDER BY
  num_hired DESC; """

#Make a get call to get the results of the first query:
@app.route("/query1", methods=['GET'])
@authetication
def query_1():
    conn = db_connection()
    cur = conn.cursor()
    cur.execute(HIRE_DETAILS)
    rows = cur.fetchall()
    cur.close()
    conn.close()

    return jsonify(rows)

#Make a get call to get the results of the second query:
@app.route("/query2", methods=['GET'])
@authetication
def query_2():
    conn = db_connection()
    cur = conn.cursor()
    cur.execute(HIRE_AMOUNT)
    rows = cur.fetchall()
    cur.close()
    conn.close()
    return jsonify(rows)

if __name__ == "__main__":
    app.run(debug=True)